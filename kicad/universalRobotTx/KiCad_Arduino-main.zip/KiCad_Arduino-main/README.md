# KiCad_Arduino

This repository currently only contains an Arduino Mega2560 Rev 3 KiCad symbol and footprint.
It was created from the official Arduino EAGLE files, so it should be accurate, but there is no guarantee (I have not tested it).
Errors may have crept in during the conversion. If you spot any error, please let me know. If you improve the symbol or footprint, please submit a merge request, and it will be accepted. Thanks!

<img width="100%" align="left" src="images\mega2560rev3_3d_render.jpg">

<img width="100%" align="left" src="images\mega2560rev3_footprint.png">

<img width="100%" align="left" src="images\mega2560rev3_symbol.png">

